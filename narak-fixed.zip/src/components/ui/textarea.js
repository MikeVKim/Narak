export function Textarea({ value, onChange, placeholder, disabled }) {
 return <textarea value={value} onChange={onChange} placeholder={placeholder} disabled={disabled} className="w-full h-24 p-2 border rounded" />;
}