import { useState } from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";

export default function MessageEscrow() {
  const [leftMessage, setLeftMessage] = useState('');
  const [rightMessage, setRightMessage] = useState('');
  const [leftLocked, setLeftLocked] = useState(false);
  const [rightLocked, setRightLocked] = useState(false);
  const [timestamp, setTimestamp] = useState('');
  const [viewed, setViewed] = useState(false);
  const [oneTimeView, setOneTimeView] = useState(false);

  const isRevealed = leftLocked && rightLocked && (!oneTimeView || !viewed);

  const handleReveal = () => {
    if (!timestamp) {
      const now = new Date().toLocaleString();
      setTimestamp(now);
    }
    if (oneTimeView) setViewed(true);
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-4">
        <Switch checked={oneTimeView} onCheckedChange={setOneTimeView} />
        <span>1회 열람 후 자동삭제</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardContent className="flex flex-col gap-4 p-4">
            <h2 className="text-xl font-bold">좌팀</h2>
            <Textarea
              placeholder="메시지를 입력하세요..."
              disabled={leftLocked}
              value={leftMessage}
              onChange={(e) => setLeftMessage(e.target.value)}
            />
            <Button onClick={() => setLeftLocked(true)} disabled={leftLocked || !leftMessage}>
              {leftLocked ? '잠금 완료' : '메시지 잠금'}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="flex flex-col gap-4 p-4">
            <h2 className="text-xl font-bold">우팀</h2>
            <Textarea
              placeholder="메시지를 입력하세요..."
              disabled={rightLocked}
              value={rightMessage}
              onChange={(e) => setRightMessage(e.target.value)}
            />
            <Button onClick={() => setRightLocked(true)} disabled={rightLocked || !rightMessage}>
              {rightLocked ? '잠금 완료' : '메시지 잠금'}
            </Button>
          </CardContent>
        </Card>
      </div>

      {leftLocked && rightLocked && !viewed && (
        <div className="text-center">
          <Button onClick={handleReveal}>메시지 열람</Button>
        </div>
      )}

      {isRevealed && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
          <Card>
            <CardContent className="p-4 space-y-2">
              <h3 className="font-bold">좌팀 메시지</h3>
              <p>{leftMessage}</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4 space-y-2">
              <h3 className="font-bold">우팀 메시지</h3>
              <p>{rightMessage}</p>
            </CardContent>
          </Card>

          <div className="col-span-2 text-center text-sm text-gray-500">
            열람 시각: {timestamp}
          </div>
        </div>
      )}
    </div>
  );
}
